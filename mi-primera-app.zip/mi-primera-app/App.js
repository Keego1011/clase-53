import React, { Component } from 'react';
import { Button, View, Text } from 'react-native';

class BlueButton extends Component{
  render(){
    return(
      <Button color="blue" title="click"/>
    )
  }
}

export default class App extends Component {
  render() {
    return (
      <View style={{marginTop:100}}>
      <BlueButton/>
        <Text style={{marginLeft:130,marginTop:200}}>Mi primera app</Text>
        </View>
    );
  }
}

